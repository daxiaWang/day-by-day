window.snBaseConfig = {
    // BASE_API: 'https://lapp.wanmeiqiye.com/',
    BASE_API: 'http://test.wanmeiqiye.com/',
    FACE_API: "https://facebus.wanmeiqiye.com",   //人脸检测接口
    needHeader: true
}